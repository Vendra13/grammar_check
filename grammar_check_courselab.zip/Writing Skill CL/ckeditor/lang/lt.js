﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.lang['lt'] = {
	"editor": "Pilnas redaktorius",
	"editorPanel": "Pilno redagtoriaus skydelis",
	"common": {
		"editorHelp": "Spauskite ALT 0 dėl pagalbos",
		"browseServer": "Naršyti po serverį",
		"url": "URL",
		"protocol": "Protokolas",
		"upload": "Siųsti",
		"uploadSubmit": "Siųsti į serverį",
		"image": "Vaizdas",
		"flash": "Flash",
		"form": "Forma",
		"checkbox": "Žymimasis langelis",
		"radio": "Žymimoji akutė",
		"textField": "Teksto laukas",
		"textarea": "Teksto sritis",
		"hiddenField": "Nerodomas laukas",
		"button": "Mygtukas",
		"select": "Atrankos laukas",
		"imageButton": "Vaizdinis mygtukas",
		"notSet": "<nėra nustatyta>",
		"id": "Id",
		"name": "Vardas",
		"langDir": "Teksto kryptis",
		"langDirLtr": "Iš kairės į dešinę (LTR)",
		"langDirRtl": "Iš dešinės į kairę (RTL)",
		"langCode": "Kalbos kodas",
		"longDescr": "Ilgas aprašymas URL",
		"cssClass": "Stilių lentelės klasės",
		"advisoryTitle": "Konsultacinė antraštė",
		"cssStyle": "Stilius",
		"ok": "OK",
		"cancel": "Nutraukti",
		"close": "Uždaryti",
		"preview": "Peržiūrėti",
		"resize": "Pavilkite, kad pakeistumėte dydį",
		"generalTab": "Bendros savybės",
		"advancedTab": "Papildomas",
		"validateNumberFailed": "Ši reikšmė nėra skaičius.",
		"confirmNewPage": "Visas neišsaugotas turinys bus prarastas. Ar tikrai norite įkrauti naują puslapį?",
		"confirmCancel": "Kai kurie parametrai pasikeitė. Ar tikrai norite užverti langą?",
		"options": "Parametrai",
		"target": "Tikslinė nuoroda",
		"targetNew": "Naujas langas (_blank)",
		"targetTop": "Viršutinis langas (_top)",
		"targetSelf": "Esamas langas (_self)",
		"targetParent": "Paskutinis langas (_parent)",
		"langDirLTR": "Iš kairės į dešinę (LTR)",
		"langDirRTL": "Iš dešinės į kairę (RTL)",
		"styles": "Stilius",
		"cssClasses": "Stilių klasės",
		"width": "Plotis",
		"height": "Aukštis",
		"align": "Lygiuoti",
		"alignLeft": "Kairę",
		"alignRight": "Dešinę",
		"alignCenter": "Centrą",
		"alignJustify": "Lygiuoti abi puses",
		"alignTop": "Viršūnę",
		"alignMiddle": "Vidurį",
		"alignBottom": "Apačią",
		"alignNone": "Niekas",
		"invalidValue": "Neteisinga reikšmė.",
		"invalidHeight": "Aukštis turi būti nurodytas skaičiais.",
		"invalidWidth": "Plotis turi būti nurodytas skaičiais.",
		"invalidCssLength": "Reikšmė nurodyta \"%1\" laukui, turi būti teigiamas skaičius su arba be tinkamo CSS matavimo vieneto (px, %, in, cm, mm, em, ex, pt arba pc).",
		"invalidHtmlLength": "Reikšmė nurodyta \"%1\" laukui, turi būti teigiamas skaičius su arba be tinkamo HTML matavimo vieneto (px arba %).",
		"invalidInlineStyle": "Reikšmė nurodyta vidiniame stiliuje turi būti sudaryta iš vieno šių reikšmių \"vardas : reikšmė\", atskirta kabliataškiais.",
		"cssLengthTooltip": "Įveskite reikšmę pikseliais arba skaičiais su tinkamu CSS vienetu (px, %, in, cm, mm, em, ex, pt arba pc).",
		"unavailable": "%1<span class=\"cke_accessibility\">, netinkamas</span>"
	},
	"basicstyles": {
		"bold": "Pusjuodis",
		"italic": "Kursyvas",
		"strike": "Perbrauktas",
		"subscript": "Apatinis indeksas",
		"superscript": "Viršutinis indeksas",
		"underline": "Pabrauktas"
	},
	"bidi": {
		"ltr": "Tekstas iš kairės į dešinę",
		"rtl": "Tekstas iš dešinės į kairę"
	},
	"blockquote": {
		"toolbar": "Citata"
	},
	"clipboard": {
		"copy": "Kopijuoti",
		"copyError": "Jūsų naršyklės saugumo nustatymai neleidžia redaktoriui automatiškai įvykdyti kopijavimo operacijų. Tam prašome naudoti klaviatūrą (Ctrl/Cmd+C).",
		"cut": "Iškirpti",
		"cutError": "Jūsų naršyklės saugumo nustatymai neleidžia redaktoriui automatiškai įvykdyti iškirpimo operacijų. Tam prašome naudoti klaviatūrą (Ctrl/Cmd+X).",
		"paste": "Įdėti",
		"pasteArea": "Įkelti dalį",
		"pasteMsg": "Žemiau esančiame įvedimo lauke įdėkite tekstą, naudodami klaviatūrą (<STRONG>Ctrl/Cmd+V</STRONG>) ir paspauskite mygtuką <STRONG>OK</STRONG>.",
		"securityMsg": "Dėl jūsų naršyklės saugumo nustatymų, redaktorius negali tiesiogiai pasiekti laikinosios atminties. Jums reikia nukopijuoti dar kartą į šį langą.",
		"title": "Įdėti"
	},
	"button": {
		"selectedLabel": "%1 (Pasirinkta)"
	},
	"colorbutton": {
		"auto": "Automatinis",
		"bgColorTitle": "Fono spalva",
		"colors": {
			"000": "Juoda",
			"800000": "Kaštoninė",
			"8B4513": "Tamsiai ruda",
			"2F4F4F": "Pilka tamsaus šiferio",
			"008080": "Teal",
			"000080": "Karinis",
			"4B0082": "Indigo",
			"696969": "Tamsiai pilka",
			"B22222": "Ugnies",
			"A52A2A": "Ruda",
			"DAA520": "Aukso",
			"006400": "Tamsiai žalia",
			"40E0D0": "Turquoise",
			"0000CD": "Vidutinė mėlyna",
			"800080": "Violetinė",
			"808080": "Pilka",
			"F00": "Raudona",
			"FF8C00": "Tamsiai oranžinė",
			"FFD700": "Auksinė",
			"008000": "Žalia",
			"0FF": "Žydra",
			"00F": "Mėlyna",
			"EE82EE": "Violetinė",
			"A9A9A9": "Dim Gray",
			"FFA07A": "Light Salmon",
			"FFA500": "Oranžinė",
			"FFFF00": "Geltona",
			"00FF00": "Citrinų",
			"AFEEEE": "Pale Turquoise",
			"ADD8E6": "Šviesiai mėlyna",
			"DDA0DD": "Plum",
			"D3D3D3": "Šviesiai pilka",
			"FFF0F5": "Lavender Blush",
			"FAEBD7": "Antique White",
			"FFFFE0": "Šviesiai geltona",
			"F0FFF0": "Honeydew",
			"F0FFFF": "Azure",
			"F0F8FF": "Alice Blue",
			"E6E6FA": "Lavender",
			"FFF": "Balta"
		},
		"more": "Daugiau spalvų...",
		"panelTitle": "Spalva",
		"textColorTitle": "Teksto spalva"
	},
	"colordialog": {
		"clear": "Išvalyti",
		"highlight": "Paryškinti",
		"options": "Spalvos nustatymai",
		"selected": "Pasirinkta spalva",
		"title": "Pasirinkite spalvą"
	},
	"templates": {
		"button": "Šablonai",
		"emptyListMsg": "(Šablonų sąrašas tuščias)",
		"insertOption": "Pakeisti dabartinį turinį pasirinktu šablonu",
		"options": "Template Options",
		"selectPromptMsg": "Pasirinkite norimą šabloną<br>(<b>Dėmesio!</b> esamas turinys bus prarastas):",
		"title": "Turinio šablonai"
	},
	"contextmenu": {
		"options": "Kontekstinio meniu parametrai"
	},
	"elementspath": {
		"eleLabel": "Elemento kelias",
		"eleTitle": "%1 elementas"
	},
	"find": {
		"find": "Rasti",
		"findOptions": "Paieškos nustatymai",
		"findWhat": "Surasti tekstą:",
		"matchCase": "Skirti didžiąsias ir mažąsias raides",
		"matchCyclic": "Sutampantis cikliškumas",
		"matchWord": "Atitikti pilną žodį",
		"notFoundMsg": "Nurodytas tekstas nerastas.",
		"replace": "Pakeisti",
		"replaceAll": "Pakeisti viską",
		"replaceSuccessMsg": "%1 sutapimas(ų) buvo pakeisti.",
		"replaceWith": "Pakeisti tekstu:",
		"title": "Surasti ir pakeisti"
	},
	"font": {
		"fontSize": {
			"label": "Šrifto dydis",
			"voiceLabel": "Šrifto dydis",
			"panelTitle": "Šrifto dydis"
		},
		"label": "Šriftas",
		"panelTitle": "Šriftas",
		"voiceLabel": "Šriftas"
	},
	"horizontalrule": {
		"toolbar": "Įterpti horizontalią liniją"
	},
	"image": {
		"alertUrl": "Prašome įvesti vaizdo URL",
		"alt": "Alternatyvus Tekstas",
		"border": "Rėmelis",
		"btnUpload": "Siųsti į serverį",
		"button2Img": "Ar norite mygtuką paversti paprastu paveiksliuku?",
		"hSpace": "Hor.Erdvė",
		"img2Button": "Ar norite paveiksliuką paversti mygtuku?",
		"infoTab": "Vaizdo informacija",
		"linkTab": "Nuoroda",
		"lockRatio": "Išlaikyti proporciją",
		"menu": "Vaizdo savybės",
		"resetSize": "Atstatyti dydį",
		"title": "Vaizdo savybės",
		"titleButton": "Vaizdinio mygtuko savybės",
		"upload": "Nusiųsti",
		"urlMissing": "Paveiksliuko nuorodos nėra.",
		"vSpace": "Vert.Erdvė",
		"validateBorder": "Reikšmė turi būti sveikas skaičius.",
		"validateHSpace": "Reikšmė turi būti sveikas skaičius.",
		"validateVSpace": "Reikšmė turi būti sveikas skaičius."
	},
	"indent": {
		"indent": "Padidinti įtrauką",
		"outdent": "Sumažinti įtrauką"
	},
	"justify": {
		"block": "Lygiuoti abi puses",
		"center": "Centruoti",
		"left": "Lygiuoti kairę",
		"right": "Lygiuoti dešinę"
	},
	"fakeobjects": {
		"anchor": "Žymė",
		"flash": "Flash animacija",
		"hiddenfield": "Paslėptas laukas",
		"iframe": "IFrame",
		"unknown": "Nežinomas objektas"
	},
	"link": {
		"acccessKey": "Prieigos raktas",
		"advanced": "Papildomas",
		"advisoryContentType": "Konsultacinio turinio tipas",
		"advisoryTitle": "Konsultacinė antraštė",
		"anchor": {
			"toolbar": "Įterpti/modifikuoti žymę",
			"menu": "Žymės savybės",
			"title": "Žymės savybės",
			"name": "Žymės vardas",
			"errorName": "Prašome įvesti žymės vardą",
			"remove": "Pašalinti žymę"
		},
		"anchorId": "Pagal žymės Id",
		"anchorName": "Pagal žymės vardą",
		"charset": "Susietų išteklių simbolių lentelė",
		"cssClasses": "Stilių lentelės klasės",
		"emailAddress": "El.pašto adresas",
		"emailBody": "Žinutės turinys",
		"emailSubject": "Žinutės tema",
		"id": "Id",
		"info": "Nuorodos informacija",
		"langCode": "Teksto kryptis",
		"langDir": "Teksto kryptis",
		"langDirLTR": "Iš kairės į dešinę (LTR)",
		"langDirRTL": "Iš dešinės į kairę (RTL)",
		"menu": "Taisyti nuorodą",
		"name": "Vardas",
		"noAnchors": "(Šiame dokumente žymių nėra)",
		"noEmail": "Prašome įvesti el.pašto adresą",
		"noUrl": "Prašome įvesti nuorodos URL",
		"other": "<kitas>",
		"popupDependent": "Priklausomas (Netscape)",
		"popupFeatures": "Išskleidžiamo lango savybės",
		"popupFullScreen": "Visas ekranas (IE)",
		"popupLeft": "Kairė pozicija",
		"popupLocationBar": "Adreso juosta",
		"popupMenuBar": "Meniu juosta",
		"popupResizable": "Kintamas dydis",
		"popupScrollBars": "Slinkties juostos",
		"popupStatusBar": "Būsenos juosta",
		"popupToolbar": "Mygtukų juosta",
		"popupTop": "Viršutinė pozicija",
		"rel": "Sąsajos",
		"selectAnchor": "Pasirinkite žymę",
		"styles": "Stilius",
		"tabIndex": "Tabuliavimo indeksas",
		"target": "Paskirties vieta",
		"targetFrame": "<kadras>",
		"targetFrameName": "Paskirties kadro vardas",
		"targetPopup": "<išskleidžiamas langas>",
		"targetPopupName": "Paskirties lango vardas",
		"title": "Nuoroda",
		"toAnchor": "Žymė šiame puslapyje",
		"toEmail": "El.paštas",
		"toUrl": "Nuoroda",
		"toolbar": "Įterpti/taisyti nuorodą",
		"type": "Nuorodos tipas",
		"unlink": "Panaikinti nuorodą",
		"upload": "Siųsti"
	},
	"list": {
		"bulletedlist": "Suženklintas sąrašas",
		"numberedlist": "Numeruotas sąrašas"
	},
	"liststyle": {
		"armenian": "Armėniški skaitmenys",
		"bulletedTitle": "Ženklelinio sąrašo nustatymai",
		"circle": "Apskritimas",
		"decimal": "Dešimtainis (1, 2, 3, t.t)",
		"decimalLeadingZero": "Dešimtainis su nuliu priekyje (01, 02, 03, t.t)",
		"disc": "Diskas",
		"georgian": "Gruziniški skaitmenys (an, ban, gan, t.t)",
		"lowerAlpha": "Mažosios Alpha (a, b, c, d, e, t.t)",
		"lowerGreek": "Mažosios Graikų (alpha, beta, gamma, t.t)",
		"lowerRoman": "Mažosios Romėnų (i, ii, iii, iv, v, t.t)",
		"none": "Niekas",
		"notset": "<nenurodytas>",
		"numberedTitle": "Skaitmeninio sąrašo nustatymai",
		"square": "Kvadratas",
		"start": "Pradžia",
		"type": "Rūšis",
		"upperAlpha": "Didžiosios Alpha (A, B, C, D, E, t.t)",
		"upperRoman": "Didžiosios Romėnų (I, II, III, IV, V, t.t)",
		"validateStartNumber": "Sąrašo pradžios skaitmuo turi būti sveikas skaičius."
	},
	"magicline": {
		"title": "Insert paragraph here"
	},
	"maximize": {
		"maximize": "Išdidinti",
		"minimize": "Sumažinti"
	},
	"pastetext": {
		"button": "Įdėti kaip gryną tekstą",
		"title": "Įdėti kaip gryną tekstą"
	},
	"pastefromword": {
		"confirmCleanup": "Tekstas, kurį įkeliate yra kopijuojamas iš Word. Ar norite jį išvalyti prieš įkeliant?",
		"error": "Dėl vidinių sutrikimų, nepavyko išvalyti įkeliamo teksto",
		"title": "Įdėti iš Word",
		"toolbar": "Įdėti iš Word"
	},
	"removeformat": {
		"toolbar": "Panaikinti formatą"
	},
	"selectall": {
		"toolbar": "Pažymėti viską"
	},
	"showblocks": {
		"toolbar": "Rodyti blokus"
	},
	"sourcearea": {
		"toolbar": "Šaltinis"
	},
	"specialchar": {
		"options": "Specialaus simbolio nustatymai",
		"title": "Pasirinkite specialų simbolį",
		"toolbar": "Įterpti specialų simbolį"
	},
	"stylescombo": {
		"label": "Stilius",
		"panelTitle": "Stilių formatavimas",
		"panelTitle1": "Blokų stiliai",
		"panelTitle2": "Vidiniai stiliai",
		"panelTitle3": "Objektų stiliai"
	},
	"table": {
		"border": "Rėmelio dydis",
		"caption": "Antraštė",
		"cell": {
			"menu": "Langelis",
			"insertBefore": "Įterpti langelį prieš",
			"insertAfter": "Įterpti langelį po",
			"deleteCell": "Šalinti langelius",
			"merge": "Sujungti langelius",
			"mergeRight": "Sujungti su dešine",
			"mergeDown": "Sujungti su apačia",
			"splitHorizontal": "Skaidyti langelį horizontaliai",
			"splitVertical": "Skaidyti langelį vertikaliai",
			"title": "Cell nustatymai",
			"cellType": "Cell rūšis",
			"rowSpan": "Eilučių Span",
			"colSpan": "Stulpelių Span",
			"wordWrap": "Sutraukti raides",
			"hAlign": "Horizontalus lygiavimas",
			"vAlign": "Vertikalus lygiavimas",
			"alignBaseline": "Apatinė linija",
			"bgColor": "Fono spalva",
			"borderColor": "Rėmelio spalva",
			"data": "Data",
			"header": "Antraštė",
			"yes": "Taip",
			"no": "Ne",
			"invalidWidth": "Reikšmė turi būti skaičius.",
			"invalidHeight": "Reikšmė turi būti skaičius.",
			"invalidRowSpan": "Reikšmė turi būti skaičius.",
			"invalidColSpan": "Reikšmė turi būti skaičius.",
			"chooseColor": "Pasirinkite"
		},
		"cellPad": "Tarpas nuo langelio rėmo iki teksto",
		"cellSpace": "Tarpas tarp langelių",
		"column": {
			"menu": "Stulpelis",
			"insertBefore": "Įterpti stulpelį prieš",
			"insertAfter": "Įterpti stulpelį po",
			"deleteColumn": "Šalinti stulpelius"
		},
		"columns": "Stulpeliai",
		"deleteTable": "Šalinti lentelę",
		"headers": "Antraštės",
		"headersBoth": "Abu",
		"headersColumn": "Pirmas stulpelis",
		"headersNone": "Nėra",
		"headersRow": "Pirma eilutė",
		"invalidBorder": "Reikšmė turi būti nurodyta skaičiumi.",
		"invalidCellPadding": "Reikšmė turi būti nurodyta skaičiumi.",
		"invalidCellSpacing": "Reikšmė turi būti nurodyta skaičiumi.",
		"invalidCols": "Skaičius turi būti didesnis nei 0.",
		"invalidHeight": "Reikšmė turi būti nurodyta skaičiumi.",
		"invalidRows": "Skaičius turi būti didesnis nei 0.",
		"invalidWidth": "Reikšmė turi būti nurodyta skaičiumi.",
		"menu": "Lentelės savybės",
		"row": {
			"menu": "Eilutė",
			"insertBefore": "Įterpti eilutę prieš",
			"insertAfter": "Įterpti eilutę po",
			"deleteRow": "Šalinti eilutes"
		},
		"rows": "Eilutės",
		"summary": "Santrauka",
		"title": "Lentelės savybės",
		"toolbar": "Lentelė",
		"widthPc": "procentais",
		"widthPx": "taškais",
		"widthUnit": "pločio vienetas"
	},
	"undo": {
		"redo": "Atstatyti",
		"undo": "Atšaukti"
	},
	"wordcount": {
		"WordCount": "Words:",
		"CharCount": "Characters:",
		"CharCountWithHTML": "Characters (including HTML):",
		"Paragraphs": "Paragraphs:",
		"title": "Statistics"
	},
	"quicktable": {
		"more": "Daugiau..."
	},
	"lineheight": {
		"title": "Line Height"
	},
	"codemirror": {
		"toolbar": "Šaltinis",
		"searchCode": "Search Source",
		"autoFormat": "Format Selection",
		"commentSelectedRange": "Comment Selection",
		"uncommentSelectedRange": "Uncomment Selection",
		"autoCompleteToggle": "Enable/Disable HTML Tag Autocomplete"
	},
	"texttransform": {
		"transformTextSwitchLabel": "Transform Text Switcher",
		"transformTextToLowercaseLabel": "Transform Text to Lowercase",
		"transformTextToUppercaseLabel": "Transform Text to Uppercase",
		"transformTextCapitalizeLabel": "Capitalize Text"
	},
	"toolbar": {
		"toolbarCollapse": "Apjungti įrankių juostą",
		"toolbarExpand": "Išplėsti įrankių juostą",
		"toolbarGroups": {
			"document": "Dokumentas",
			"clipboard": "Atmintinė/Atgal",
			"editing": "Redagavimas",
			"forms": "Formos",
			"basicstyles": "Pagrindiniai stiliai",
			"paragraph": "Paragrafas",
			"links": "Nuorodos",
			"insert": "Įterpti",
			"styles": "Stiliai",
			"colors": "Spalvos",
			"tools": "Įrankiai"
		},
		"toolbars": "Redaktoriaus įrankiai"
	}
};