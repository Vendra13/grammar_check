// InitModule
function InitModule()
{
}

// ShutdownModule
function ShutdownModule()
{
}

function formText(text){
	var cond = true;
	while (cond){
		var textLength = text.length-1;
		var endChar = text.substr(textLength,1);
		if (endChar == '.'){text=text.substr(0,(textLength));}
		else {cond=false};
	}		
	while (text.indexOf(' ') !== -1){
		text = text.replace(' ','+');
	};
	var lText = text;	
	return lText;		
}

function clearText(text){
	while (text.indexOf('.') !== -1){text = text.replace('.','');}
	while (text.indexOf(',') !== -1){text = text.replace(',','');}
	return text;
}

function grammar(text,output,download){
	CLO[download].Show({ bMaster: true });
	texts = formText(text);
	var url = "https://api.textgears.com/check.php?text="+text+"&key=a4ELLJkmGzY7gArA";
	$(document).ready(function(){
		$.ajax({
			crossDomain: true,
			url: url,
			method: 'GET',
			dataType: 'text',
			success: function (resp){
					var json = result(resp,text);
					var view = document.getElementById(output);
					view.innerHTML = "<html>"+json+"";
					CLO[download].Hide({ bMaster: true });
				},		
			error: function (e){alert('Network error');}
		})	
	})
}

function color(text,clrText){
	//alert(clrText.length);
	let arrayText = text.split(' ');
	let count = 0;
	let ctext = '';
	for (i=1;i<clrText.length;i++){	
		for (j=count;j<arrayText.length;j++){
			let buffText = clearText(arrayText[j]);
			//alert(clrText[i].bad+' --- '+arrayText[j]);
			if (clrText[i].bad==buffText){
				arrayText[j]=arrayText[j].fontcolor( "red" );
				count++;
				break;
			}
			count++;
		}
	};
	for (j=0;j<arrayText.length;j++){
		ctext += arrayText[j] + ' ';
	}
	return ctext;
}

function result(json,text){
	let html='';
	let ntext=text;
	let newtext ='';
	let error ='';
	let fjson = JSON.parse(json);
	let ejson = fjson.errors;
	console.log(json);
	if (ejson!=''){
		let ejson = fjson.errors;
		let loop = true;
		let index = 0;
		let clrText = [];
		while (loop){
			if (ejson[index]!= null){
				index++;
				let e = JSON.stringify(ejson[index-1]);
				let p = JSON.parse(e);
				let offset = p.offset;
				let bad = p.bad;
				clrText[index]={"offset":offset,"bad":bad}; 
			}
			else {loop=false;}
		}
		ntext = color(text,clrText);
		index = 0;
		loop = true;
		while (loop){
			if (ejson[index]!= null){
				index++;
				let e = JSON.stringify(ejson[index-1]);
				let p = JSON.parse(e);
				let bad = p.bad;
				let better = p.better;
				let offset = p.offset;
				let length = p.length;
				let type = p.type;
				error += '<p>error: <b>'+type+'</b> bad: <b>'+
						 bad+'</b> better: <b>'+better+'</b></p>';		 
			}
			else {loop=false;}
		}
	} else {error = '<p>There is no error</p>'};
	html = '<p>'+ntext+'</p>';
	return html+error;
}